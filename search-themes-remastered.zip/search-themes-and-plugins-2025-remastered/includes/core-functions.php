<?php
/**
 * Core Functions
 * Main plugin functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

function wpnull_plugin_init() {
    // Plugin initialization code
}

function wpnull_register_post_types() {
    // Custom post types registration
} 